<?php
/**
 * GCODE Admin - Logout Seguro
 */

require_once 'config/auth.php';

$auth = new AuthManager();
$auth->logout();

header('Location: login.php?message=logout_success');
exit;
?>