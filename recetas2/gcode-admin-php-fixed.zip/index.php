<?php
/**
 * GCODE Admin - Página Principal Segura
 */

require_once 'config/auth.php';
require_once 'includes/database.php';

$auth = new AuthManager();
$auth->requireAuth();

$db = new SecureDatabase();
$tables = $db->getAllTables();
$user = $auth->getCurrentUser();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GCODE Admin - Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            background: linear-gradient(45deg, #2c3e50, #3498db) !important;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .main-container {
            margin-top: 2rem;
        }
        .welcome-card {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
        }
        .table-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 1.5rem;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .table-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        .table-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(45deg, #28a745, #20c997);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
        }
        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#"><i class="fas fa-database"></i> GCODE Admin</a>
            <div class="navbar-nav ms-auto">
                <span class="navbar-text me-3">
                    <i class="fas fa-user"></i> <?= htmlspecialchars($user['username']) ?>
                </span>
                <a href="logout.php" class="btn btn-outline-light btn-sm">
                    <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                </a>
            </div>
        </div>
    </nav>

    <div class="container main-container">
        <!-- Welcome Section -->
        <div class="welcome-card">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1><i class="fas fa-tachometer-alt"></i> Dashboard</h1>
                    <p class="mb-0">Bienvenido al sistema de administración seguro. Gestiona tus datos de forma fácil y segura.</p>
                </div>
                <div class="col-md-4 text-end">
                    <div class="stats-overview">
                        <h3><?= count($tables) ?></h3>
                        <p>Tablas Disponibles</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tables Grid -->
        <div class="row">
            <div class="col-12">
                <h2 class="mb-4"><i class="fas fa-table"></i> Tablas de la Base de Datos</h2>
            </div>
            
            <?php if (empty($tables)): ?>
                <div class="col-12">
                    <div class="alert alert-info" role="alert">
                        <i class="fas fa-info-circle"></i> No hay tablas disponibles para mostrar.
                    </div>
                </div>
            <?php else: ?>
                <?php foreach ($tables as $table): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="table-card">
                            <div class="card-body p-4">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="table-icon me-3">
                                        <i class="fas fa-table"></i>
                                    </div>
                                    <div>
                                        <h5 class="card-title mb-1"><?= htmlspecialchars($table) ?></h5>
                                        <small class="text-muted">Tabla de datos</small>
                                    </div>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <a href="table.php?name=<?= urlencode($table) ?>" class="btn btn-primary">
                                        <i class="fas fa-eye"></i> Ver Datos
                                    </a>
                                    <a href="export.php?table=<?= urlencode($table) ?>&format=json" class="btn btn-outline-success btn-sm">
                                        <i class="fas fa-download"></i> Exportar JSON
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Quick Actions -->
        <div class="row mt-5">
            <div class="col-12">
                <h3><i class="fas fa-bolt"></i> Acciones Rápidas</h3>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <i class="fas fa-shield-alt fa-2x text-success mb-3"></i>
                    <h6>Sistema Seguro</h6>
                    <small class="text-muted">Protección completa activada</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <i class="fas fa-history fa-2x text-info mb-3"></i>
                    <h6>Log de Actividad</h6>
                    <small class="text-muted">Todas las acciones registradas</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <i class="fas fa-search fa-2x text-warning mb-3"></i>
                    <h6>Búsqueda Avanzada</h6>
                    <small class="text-muted">Encuentra datos rápidamente</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <i class="fas fa-download fa-2x text-primary mb-3"></i>
                    <h6>Exportación Múltiple</h6>
                    <small class="text-muted">JSON, CSV, XML</small>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>