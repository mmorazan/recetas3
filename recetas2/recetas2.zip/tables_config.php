<?php
/**
 * GCODE Admin - Configuración de Tablas Permitidas
 * Solo cambiar aquí para actualizar todas las páginas
 */

$allowedTables = [
    'users', 
    'products', 
    'admin_users', 
    'activity_log',
    'Ingredientes',
    'Categorias'
];
?>